
// function select_years(years) {
//     var Choice = ["연도 선택"];
//     var Seoul = ["2018", "2019", "2020", "2021", "2022", "2023"];
//     도 선택에 따른 시/군/구 표시
//     var target = document.getElementById("select_graph");
//     if (years.value == "Choice") var location = Choice;
//     else if (years.value == "Seoul") var location = Seoul;
//     target.options.length = 0;
//     for (x in location) {
//         var opt = document.createElement("option");
//         opt.value = location[x];
//         opt.innerHTML = location[x];
//         target.appendChild(opt);
//     }
// }

var ctx = document.getElementById('myChart');
var ctx1 = document.getElementById('myChart1');
var ctx2 = document.getElementById('myChart2');
var config = {
type: 'bar',

data: {
    labels: [ // Date Objects
        '2021',
        '2022',
        '2023'
        
    ],
    datasets: [{
        label: '기존',
        backgroundColor: 'rgba(75, 192, 192, 1)',
        borderColor: 'rgba(75, 192, 192, 1)',
        fill: false,
        data: [
            Math.floor(Math.random() * 50),
            Math.floor(Math.random() * 50),
            Math.floor(Math.random() * 50)
           
            
        ],
    }, {
        label: '변화',
        backgroundColor: 'rgba(255, 99, 132, 1)',
        borderColor: 'rgba(255, 99, 132, 1)',
        fill: false,
        data: [
            Math.floor(Math.random() * 50),
            Math.floor(Math.random() * 50),
            Math.floor(Math.random() * 50)
            
            
        ],
    }]
},
options: {
    maintainAspectRatio: false,
    title: {
        text: '검거율'
    },
    scales: {
        yAxes: [{
            scaleLabel: {
                display: true,
                labelString: '차트'
            }
        }]
    },
}
};

//차트 그리기
var myChart = new Chart(ctx, config);
var myChart1 = new Chart(ctx1, config);
var myChart2 = new Chart(ctx2, config);

//데이터 변경
document.getElementById('reData').onclick = function(){

//데이터셋 수 만큼 반복
var dataset = config.data.datasets;
for(var i=0; i<dataset.length; i++){
    console.log(dataset);
    //데이터 갯수 만큼 반복
    var data = dataset[i].data;
    for(var j=0 ; j < data.length ; j++){
        data[j] = Math.floor(Math.random() * 50);
    }
}

myChart.update();	//차트 업데이트
}

document.getElementById('reData1').onclick = function(){

//데이터셋 수 만큼 반복
var dataset = config.data.datasets;
for(var i=0; i<dataset.length; i++){
    console.log(dataset);
    //데이터 갯수 만큼 반복
    var data = dataset[i].data;
    for(var j=0 ; j < data.length ; j++){
        data[j] = Math.floor(Math.random() * 50);
    }
}

myChart1.update();	//차트 업데이트
}

document.getElementById('reData2').onclick = function(){

//데이터셋 수 만큼 반복
var dataset = config.data.datasets;
for(var i=0; i<dataset.length; i++){
    console.log(dataset);
    //데이터 갯수 만큼 반복
    var data = dataset[i].data;
    for(var j=0 ; j < data.length ; j++){
        data[j] = Math.floor(Math.random() * 50);
    }
}

myChart2.update();	//차트 업데이트
}

document.getElementById('reData3').onclick = function(){

//데이터셋 수 만큼 반복
var dataset = config.data.datasets;
for(var i=0; i<dataset.length; i++){
    console.log(dataset);
    //데이터 갯수 만큼 반복
    var data = dataset[i].data;
    for(var j=0 ; j < data.length ; j++){
        data[j] = Math.floor(Math.random() * 50);
    }
}

myChart2.update();	//차트 업데이트
}
document.getElementById('reData4').onclick = function(){

//데이터셋 수 만큼 반복
var dataset = config.data.datasets;
for(var i=0; i<dataset.length; i++){
    console.log(dataset);
    //데이터 갯수 만큼 반복
    var data = dataset[i].data;
    for(var j=0 ; j < data.length ; j++){
        data[j] = Math.floor(Math.random() * 50);
    }
}

myChart1.update();	//차트 업데이트
}

