
function positiveValue(input) {
  const countNum = parseInt(input.value);

  if (isNum(countNum) || countNum < 0) {
    alert('값은 0 이상이어야 합니다.');

    input.value = "";
  }
}
const originalData = {

  gangnam: [50, 30, 10, 20, 50],
  jongno: [20, 15, 5, 30, 20],
  mapo: [40, 25, 8, 30, 40],
  songpa: [45, 20, 15, 50, 10],
  yongsan: [35, 22, 12, 39, 29]

};


let chart;


function updateChart() {
  document.getElementById("byeDiv").innerHTML = " ";

  document.getElementById('myChart').style.display = 'block';
  document.getElementById('crimeRate').style.display = 'block';
  const selectedDistrict = document.getElementById('districtSelector').value;

  document.getElementById("predictionResult").style.display = "block";


  const currentData = originalData[selectedDistrict];


  const expectedData = {
    cctv: null,
    streetlight: null,
    policeStation: null
  };

  const cctvChecked = document.getElementById('cctvCheckbox').checked;
  const streetlightChecked = document.getElementById('streetlightCheckbox').checked;
  const policeStationChecked = document.getElementById('policeStationCheckbox').checked;

  expectedData.cctv = cctvChecked ? parseInt(document.getElementById('cctvValue').value) : null;
  expectedData.streetlight = streetlightChecked ? parseInt(document.getElementById('streetlightValue').value) : null;
  expectedData.policeStation = policeStationChecked ? parseInt(document.getElementById('policeStationValue').value) : null;

  const updatedData = {
    labels: ['살인', '강도', '성범죄', '폭행', '절도'],
    datasets: [
      {
        label: '현재값',
        data: currentData,
        backgroundColor: 'rgba(10, 132, 14, 0.5)',
        borderColor: 'rgba(7, 77, 9, 1)',
        borderWidth: 1
      },
      {
        label: '예측값',
        data: [
          cctvChecked ? currentData[0] - expectedData.cctv : currentData[0],
          cctvChecked ? currentData[1] - expectedData.cctv : currentData[1],
          cctvChecked ? currentData[2] - expectedData.cctv : currentData[2],
          cctvChecked ? currentData[3] - expectedData.cctv : currentData[3],
          cctvChecked ? currentData[4] - expectedData.cctv : currentData[4]
        ],
        backgroundColor: 'rgba(54, 162, 235, 0.5)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1
      },
    ]
  };


  if (chart) {
    chart.destroy();
  }

  const bar = document.getElementById('myChart').getContext('2d');
  chart = new Chart(bar, {
    type: 'bar',
    data: updatedData,
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });

  const crimeData = {

    "2030": [15, 20, 25, 30, 37],
    "2029": [18, 23, 28, 33, 40],
    "2028": [20, 25, 30, 35, 42],
    "2027": [10, 15, 20, 25, 30],
    "2026": [10, 15, 20, 25, 30],
    "2025": [12, 18, 22, 28, 35],
    "2024": [15, 20, 25, 30, 37],
    "2023": [18, 23, 28, 33, 40],
    "2022": [20, 25, 30, 35, 42],
    "2021": [10, 15, 20, 25, 30],
    "2020": [12, 18, 22, 28, 35],
    "2019": [15, 20, 25, 30, 37],
    "2018": [18, 23, 28, 33, 40],
    "2017": [20, 25, 30, 35, 42],
    "2016": [10, 15, 20, 25, 30],

  };


  // ---------
  updateCrimeChart();


  function updateCrimeChart() {

    const ctx = document.getElementById('crimeChart').getContext('2d');
    const myChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ["2017", "2018", "2019", "2020", "2021"],
        datasets: [{
          label: '살인',
          data: [10, 20, 30],
          borderColor: 'blue',
          borderWidth: 1
        }, {
          label: '강도',
          data: [1, 30, 45],
          borderColor: 'red',
          borderWidth: 1
        }, {
          label: '성범죄',
          data: [15, 25, 35],
          borderColor: 'black',
          borderWidth: 1
        }, {
          label: '폭행',
          data: [35, 15, 75],
          borderColor: 'green',
          borderWidth: 1
        }, {
          label: '절도',
          data: [5, 52, 25],
          borderColor: 'yellow',
          borderWidth: 1
        },
        ]
      },
      options: {
        scales: {
          x: {
            beginAtZero: true
          },
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }


}


(function () {
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  tooltipTriggerList.forEach(function (tooltipTriggerEl) {
    new bootstrap.Tooltip(tooltipTriggerEl)
  })
})()