var local = "강남구";
console.log(local)

window.onload = function () {

  //셀렉트박스 자치구 바뀔때마다 차트도 바꿔주는 함수

  //차트 지우고 업데이트
  const removeData = (chart) => {
    chart.data.labels = [];
  
    chart.update();
  }

  const addData = (chart, local) => {
    removeData(chart);
    chart.data.labels = ['평균', local];
    chart.update();
  };


  //셀렉트박스 
  var selectregion = document.getElementById("selectbox");
  selectregion.addEventListener('input', function () {
    local = $("#selectbox option:selected").val();
    // console.log("2nd" + local)

    addData(securityChart1, local);
    addData(securityChart2, local);
    addData(securityChart3, local);


  });


  var security_data = {
    labels: ['평균', local],
    //a 강남구의 범례
    datasets: [{
      label: [
        ' 지역 '
      ],

      data: [75, 51],
      backgroundColor: ['#43c2c2', '#4eddad'],
    }]
  };
  var ctx1 = document.getElementById('myChart1').getContext('2d');
  var securityChart1 = new Chart(ctx1, {
    type: 'bar',
    data: security_data,
    options: {

      x: {
        //차트 옵션, css같은 느낌 양식다름, 
      },
      y: {

      },
      plugins: {
        legend: {
          display: false,
        }
      },
      //plugins안에 
      maintainAspectRatio: false

    }
  });


  var ctx2 = document.getElementById('myChart2').getContext('2d');
  var securityChart2 = new Chart(ctx2, {
    type: 'bar',
    data: security_data,
    options: {
      x: {
        //차트 옵션, css같은 느낌 양식다름, 
      },
      y: {

      },
      plugins: {
        legend: {
          display: false,
        }
      },
      maintainAspectRatio: false
      // reponsive : false

    }
  });


  var ctx3 = document.getElementById('myChart3').getContext('2d');
  var securityChart3 = new Chart(ctx3, {
    type: 'bar',
    data: security_data,
    options: {
      x: {
        //차트 옵션, css같은 느낌 양식다름, 
      },
      y: {

      },
      plugins: {
        legend: {
          display: false,
        }
      },
      //이게 사이즈 바꿔주는거
      maintainAspectRatio: false
    }
  });






  // ----------------------------------------------------------


  var data = {
    labels: ['2004', '2007', '2010', '2013', '2015', '2018', '2022'],
    datasets: [{
      label: '검거율',
      data: [65, 59, 80, 81, 56, 55, 40],
      fill: false,
      borderColor: 'rgb(75, 192, 192)',
      tension: 0.1
    }]
  };
  var ctx = document.getElementById('safetyChart').getContext('2d');
  var safetyChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
      maintainAspectRatio: false
    }
  });


  document.addEventListener('DOMContentLoaded', function () {

    var buttons = document.querySelectorAll('.btn-group button');

    // 각 버튼에 클릭 이벤트 리스너 등록
    buttons.forEach(function (button) {
      button.addEventListener('click', function () {
        // 클릭된 버튼의 ID 가져오기
        var buttonID = button.id;

        // ID에 따라 #lower의 내용 변경
        switch (buttonID) {
          case "three":
            document.getElementById("lower").innerHTML = "<p>2023 년도 1위</p>";
            break;
          case "two":
            document.getElementById("lower").innerHTML = "<p>2022 년도 2위</p>";
            break;
          case "one":
            document.getElementById("lower").innerHTML = "<p>2021 년도 4위</p>";
            break;
          case "zero":
            document.getElementById("lower").innerHTML = "<p>2020 년도 5위</p>";
            break;
          case "nine":
            document.getElementById("lower").innerHTML = "<p>2019 년도 9위</p>";
            break;
          default:
            document.getElementById("lower").innerHTML = "<p>기본 내용</p>";
            break;
        }
      });
    });
  });

}