window.onload = function () {
    const districtData = {
        gangnam: {
            facilitySelector: {
                cctvCount: [100, 110, 120, 130, 140, 150, 160, 170],
                streetLampCount: [200, 220, 240, 260, 280, 300, 320, 340],
                policeStationCount: [3, 6, 9, 12, 14, 16, 18, 20],
            },
            crimeData: {
                murder: [8, 4, 6, 5, 4, 3, 2, 3],
                robbery: [40, 30, 38, 33, 30, 24, 25, 20],
                sexualAssault: [100, 80, 70, 80, 60, 40, 30, 40],
                assault: [130, 122, 110, 80, 90, 70, 60, 50],
                theft: [230, 210, 220, 200, 180, 170, 130, 160]
            }
        },
        jongno: {
            facilitySelector: {
                cctvCount: [80, 90, 80, 90, 100, 110, 120, 130],
                streetLampCount: [150, 160, 170, 180, 190, 200, 210, 220],
                policeStationCount: [2, 6, 4, 5, 6, 6, 6, 7],
            },

            crimeData: {
                murder: [87, 76, 65, 54, 43, 32, 21, 10],
                robbery: [97, 86, 75, 64, 53, 42, 31, 20],
                sexualAssault: [102, 91, 81, 71, 60, 50, 40, 30],
                assault: [34, 34, 35, 36, 37, 38, 39, 40],
                theft: [124, 113, 102, 92, 81, 71, 60, 50]
            }
        },
        mapo: {
            facilitySelector: {
                cctvCount: [124, 113, 102, 92, 81, 71, 60, 50],
                streetLampCount: [865, 750, 635, 520, 405, 290, 175, 60],
                policeStationCount: [88, 86, 85, 84, 83, 82, 81, 80],
            },
            crimeData: {
                murder: [612, 537, 462, 388, 313, 239, 164, 90],
                robbery: [858, 749, 641, 533, 424, 316, 208, 100],
                sexualAssault: [23, 35, 47, 60, 72, 85, 97, 110],
                assault: [68, 76, 85, 94, 103, 112, 121, 130],
                theft: [123, 125, 127, 130, 132, 135, 137, 140]
            }
        },
        songpa: {
            facilitySelector: {
                cctvCount: [23, 35, 47, 60, 72, 85, 97, 110],
                streetLampCount: [68, 76, 85, 94, 103, 112, 121, 130],
                policeStationCount: [123, 125, 127, 130, 132, 135, 137, 140],
            },
            crimeData: {
                murder: [444, 402, 360, 318, 276, 234, 192, 150],
                robbery: [65, 78, 92, 105, 119, 132, 146, 160],
                sexualAssault: [34, 34, 35, 36, 37, 38, 39, 40],
                assault: [865, 750, 635, 520, 405, 290, 175, 60],
                theft: [87, 76, 65, 54, 43, 32, 21, 10]
            }
        },
        yongsan: {
            facilitySelector: {
                cctvCount: [65, 78, 92, 105, 119, 132, 146, 160],
                streetLampCount: [123, 125, 127, 130, 132, 135, 137, 140],
                policeStationCount: [23, 35, 47, 60, 72, 85, 97, 110],
            },
            crimeData: {
                murder: [88, 86, 85, 84, 83, 82, 81, 80],
                robbery: [612, 537, 462, 388, 313, 239, 164, 90],
                sexualAssault: [23, 35, 47, 60, 72, 85, 97, 110],
                assault: [124, 113, 102, 92, 81, 71, 60, 50],
                theft: [87, 76, 65, 54, 43, 32, 21, 10]
            }
        }
    };
    var myChart

    var selectbox = document.getElementById('districtSelector')
    var local;
    var facil;
    selectbox.addEventListener('input', function () {
        Chart.getChart(myChart)?.destroy();
        local = selectbox.value;
        facil = "cctvCount"
        showchart(local, facil);
        console.log(districtData)
    })

    var cctvbtn = document.getElementById('cctv');
    cctvbtn.addEventListener('click', function () {
        Chart.getChart(myChart)?.destroy();
        facil = "cctvCount"
        showchart(local, facil);
        console.log(districtData[local].facilitySelector[facil])
        document.getElementById('currentCctvCount').innerHTML = '<span>CCTV 현재수:' + districtData[local].facilitySelector[facil][5]
    })

    var lightbtn = document.getElementById('light');
    lightbtn.addEventListener('click', function () {
        Chart.getChart(myChart)?.destroy();
        facil = "streetLampCount"
        showchart(local, facil);


        document.getElementById('currentCctvCount').innerHTML = '<span>보안등 현재수:' + districtData[local].facilitySelector[facil][5]

    })

    var policebtn = document.getElementById('policeOffice');
    policebtn.addEventListener('click', function () {
        Chart.getChart(myChart)?.destroy();
        facil = "policeStationCount"
        showchart(local, facil);
        document.getElementById('currentCctvCount').innerHTML = '<span>경찰관서 현재수:' + districtData[local].facilitySelector[facil][5]
    })


    function showchart(local, facil) {
        var ctx = document.getElementById('clickChart1').getContext('2d')
        myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: districtData[local].facilitySelector[facil], // X축 레이블
                datasets: [{
                    label: '살인',
                    data: districtData[local].crimeData.murder,
                    borderColor: 'blue', // 첫 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '강도',
                    data: districtData[local].crimeData.robbery,
                    borderColor: 'red', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '성범죄',
                    data: districtData[local].crimeData.sexualAssault,
                    borderColor: 'green', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '폭행',
                    data: districtData[local].crimeData.assault,
                    borderColor: 'violet', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '절도',
                    data: districtData[local].crimeData.theft,
                    borderColor: 'orange', // 두 번째 라인의 색상
                    borderWidth: 1
                }
                ]
            },
            options: {}
        })
    }



    function showchart2(local) {
        var ctx = document.getElementById('clickChart1').getContext('2d')
        myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: districtData[local].facilitySelector.streetLampCount, // X축 레이블
                datasets: [{
                    label: '살인',
                    data: districtData[local].crimeData.murder,
                    borderColor: 'blue', // 첫 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '강도',
                    data: districtData[local].crimeData.robbery,
                    borderColor: 'red', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '성범죄',
                    data: districtData[local].crimeData.sexualAssault,
                    borderColor: 'green', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '폭행',
                    data: districtData[local].crimeData.assault,
                    borderColor: 'violet', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '절도',
                    data: districtData[local].crimeData.theft,
                    borderColor: 'orange', // 두 번째 라인의 색상
                    borderWidth: 1
                }
                ]
            },
            options: {}
        })
    }




    function showchart3(local) {
        var ctx = document.getElementById('clickChart1').getContext('2d')
        myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: districtData[local].facilitySelector.policeStationCount, // X축 레이블
                datasets: [{
                    label: '살인',
                    data: districtData[local].crimeData.murder,
                    borderColor: 'blue', // 첫 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '강도',
                    data: districtData[local].crimeData.robbery,
                    borderColor: 'red', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '성범죄',
                    data: districtData[local].crimeData.sexualAssault,
                    borderColor: 'green', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '폭행',
                    data: districtData[local].crimeData.assault,
                    borderColor: 'violet', // 두 번째 라인의 색상
                    borderWidth: 1
                }, {
                    label: '절도',
                    data: districtData[local].crimeData.theft,
                    borderColor: 'orange', // 두 번째 라인의 색상
                    borderWidth: 1
                }
                ]
            },
            options: {}
        })
    }






















}