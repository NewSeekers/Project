var mapContainer = document.getElementById('park_map'),
    mapOption = {
        center: new kakao.maps.LatLng(37.5213259, 127.052453), level: 3
    };

var map = new kakao.maps.Map(mapContainer, mapOption);
var marker = new kakao.maps.Marker({
    // 지도 중심좌표에 마커를 생성합니다 
    position: map.getCenter()
});
// 지도에 마커를 표시합니다
marker.setMap(map);

// 지도에 표시할 원을 생성합니다

var circle = new kakao.maps.Circle({
    center: new kakao.maps.LatLng(37.5213259, 127.052453),  // 원의 중심좌표 입니다 
    radius: 250, // 미터 단위의 원의 반지름입니다 
    strokeWeight: 2, // 선의 두께입니다 
    strokeColor: '#75B8FA', // 선의 색깔입니다
    strokeOpacity: 0.5, // 선의 불투명도 입니다 1에서 0 사이의 값이며 0에 가까울수록 투명합니다
    strokeStyle: 'dashed', // 선의 스타일 입니다
    fillColor: '#CFE7FF', // 채우기 색깔입니다
    fillOpacity: 0.7  // 채우기 불투명도 입니다   

});
circle.setMap(map);


//클릭했을때의 모션

kakao.maps.event.addListener(map, 'click', function (mouseEvent) {
    var latlng = mouseEvent.latLng;
    marker.setPosition(latlng);

    //원도 포지션 바꿔줘야 이동.
    circle.setPosition(latlng);
});


/* ********* park 정보 바꿔주기 ****************************************************** */


var parks;
var parks_LatLng = [];
// var parks_Lng = [];
fetch('./json/seoul_park.json')
    .then(response => response.json())
    .then(mapData => {
        parks = mapData.DATA;
        // console.log(parks[0]);


        parks_data = [];
        for (let i = 0; i < parks.length; i++) {
            var p_name = parks[i].p_park;
            var p_info = parks[i].p_name;
            var p_num = parks[i].p_admintel;
            var p_content = parks[i].p_list_content;
            var p_parking = parks[i].use_refer;
            var p_road = parks[i].visit_road;
            var p_lat = parks[i].latitude;
            var p_lng = parks[i].longitude;

            var park_info = { p_name, p_info, p_num, p_content, p_parking, p_road, p_lat, p_lng };
            parks_data.push(park_info);

        }

        var markers = [];
        kakao.maps.event.addListener(map, 'click', function (mouseEvent) {




            for (let i = 0; i < parks_data.length; i++) {
                var park_marker = new kakao.maps.Marker({
                    title: parks_data[i].p_name,
                    map: map, // 마커를 표시할 지도
                    position: new kakao.maps.LatLng(parks_data[i].p_lat, parks_data[i].p_lng) // 마커의 위치                   

                });

                markers.push(park_marker);
                markers[i].setMap(map);


            }


        });


        console.log(circle.getRadius());
    })
    .catch(error => {
        console.log('hi');
    });



var geocoder = new kakao.maps.services.Geocoder();

var marker = new kakao.maps.Marker(), // 클릭한 위치를 표시할 마커입니다
    infowindow = new kakao.maps.InfoWindow({ zindex: 1 }); // 클릭한 위치에 대한 주소를 표시할 인포윈도우입니다

searchAddrFromCoords(map.getCenter(), displayCenterInfo);

kakao.maps.event.addListener(map, 'click', function (mouseEvent) {
    searchDetailAddrFromCoords(mouseEvent.latLng, function (result, status) {
        if (status === kakao.maps.services.Status.OK) {

            var detailAddr = result[0].address.region_2depth_name;

            // !!result[0].road_address ? '<div>도로명주소 : ' + result[0].road_address.address_name + '</div>' : '';
            // detailAddr += '<div>지번 주소 : ' + result[0].address.address_name + '</div>';

            var content = '<div class="bAddr">' +
                '<span class="title">' + detailAddr + '</span></div>';

            // 마커를 클릭한 위치에 표시합니다 
            marker.setPosition(mouseEvent.latLng);
            marker.setMap(map);


            infowindow.setContent(content);
            infowindow.open(map, marker);

        }
    });
});

// 중심 좌표나 확대 수준이 변경됐을 때 지도 중심 좌표에 대한 주소 정보를 표시하도록 이벤트를 등록합니다
kakao.maps.event.addListener(map, 'idle', function () {
    searchAddrFromCoords(map.getCenter(), displayCenterInfo);
});

function searchAddrFromCoords(coords, callback) {
    // 좌표로 행정동 주소 정보를 요청합니다
    geocoder.coord2RegionCode(coords.getLng(), coords.getLat(), callback);
}
function searchDetailAddrFromCoords(coords, callback) {
    // 좌표로 법정동 상세 주소 정보를 요청합니다
    geocoder.coord2Address(coords.getLng(), coords.getLat(), callback);
}

// 지도 좌측상단에 지도 중심좌표에 대한 주소정보를 표출하는 함수입니다
function displayCenterInfo(result, status) {
    if (status === kakao.maps.services.Status.OK) {
        var infoDiv = document.getElementById('centerAddr');

        for (var i = 0; i < result.length; i++) {
            // 행정동의 region_type 값은 'H' 이므로
            if (result[i].region_type === 'H') {
                infoDiv.innerHTML = result[i].address_name;
                break;
            }
        }
    }
}