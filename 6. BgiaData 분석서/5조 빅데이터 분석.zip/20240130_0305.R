peo_density <- original$population/original_base$area
original <- cbind(original[,c(1:3)],peo_density,original[,c(4:15)])
grdp_pp <- original$grdp/original$population
original <- cbind(original[,c(1:7)],grdp_pp,original[,c(8:15)])

mod1 <- lm(homicide~population+lights+pub+grdp+policestation+cctv+single+policeman, data=total_per_area[,-c(1:2)])
summary(mod1)     
mod2 <- step(mod1, direction = "both")
summary(mod2)

mod1 <- lm(theft~lights+pub+grdp+policestation+cctv+single+policeman, data=total_per_density[,-c(1:2)])
summary(mod1)     
mod2 <- step(mod1, direction = "both")
summary(mod2)

ggpairs(total_per_density_rmout[,-c(1,2)])

find_outliers_zscore <- function(data, threshold = 3) {
  mean_val <- mean(data)
  std_dev <- sd(data)
  
  z_scores <- (data - mean_val) / std_dev
  
  return(data[abs(z_scores) > threshold])
}

find_outliers_iqr <- function(data, k = 1.5) {
  q1 <- quantile(data, 0.25)
  q3 <- quantile(data, 0.75)
  
  iqr <- q3 - q1
  
  lower_bound <- q1 - k * iqr
  upper_bound <- q3 + k * iqr
  
  return(data[data < lower_bound | data > upper_bound])
}

outliers <- find_outliers_zscore(total_per_density_rmout$homicide)
outliers

outliers <- find_outliers_iqr(total_per_density_rmout$pub)
temp <- which(total_per_density_rmout$pub==outliers[1])
total_per_density_rmout <- total_per_density_rmout[-temp,]


tpdsr <- total_per_density_std


for(i in c(3:14)){
    colum_data <- unlist(tpdsr[,i])
    outliers <- find_outliers_iqr(colum_data)
if(0 != length(outliers)){
  for(j in 1:length(outliers)){
temp <- which(tpdsr[,i]==outliers[j])
for(k in 1:length(temp)){
tpdsr <- tpdsr[-temp[k],]}}}}

ggpairs(tpdsr[,-c(1,2)])


mod1 <- lm(violence~lights+pub+grdp+policestation+cctv+single+policeman, data=total_per_density_rmout[,-c(1:2)])
summary(mod1)     
mod2 <- step(mod1, direction = "both")
summary(mod2)

head(colum_data)

predict(mod2, total_per_density_rmout[1,3:9])


par(mfrow=c(2,2))
plot(mod2)

# 릿지 회귀 적용
library(glmnet)

x <- model.matrix(violence ~ lights+pub+grdp+policestation+cctv+single+policeman, data=total_per_density_rmout[,-c(1,2)])[,-1]
y <- total_per_density_rmout$violence

ridge_model <- glmnet(x, y, alpha=0)  # alpha=0: 릿지 회귀

cv_fit <- cv.glmnet(x, y, alpha=0, standardize=TRUE)

plot(cv_fit)

best_lambda <- cv_fit$lambda.min
best_model <- glmnet(x, y, alpha=0, lambda=best_lambda, standardize=TRUE)

coef(best_model)

predictions <- predict(best_model, newx=total_per_density_rmout[1,3:9])
performance <- mean((predictions - y)^2)

#k겹 교차검증
library(caret)
# 5-겹 교차 검증을 수행합니다.
control <- trainControl(method = "cv", number = 5)
model <- train(violence ~ lights+pub+grdp+policestation+cctv+single+policeman, data=total_per_density_rmout[,-c(1,2)], method = "lm", trControl = control)

# 교차 검증 결과를 출력합니다.
print(model)

hist(total_per_density_rmout$lights)
hist(sqrt(total_per_density_rmout$lights+1))
hist(scale(total_per_density_rmout$lights))
hist(scale(total_per_density_rmout$lights, center = min(total_per_density_rmout$lights), scale = max(total_per_density_rmout$lights) - min(total_per_density_rmout$lights)))

for(i in 3:14){
  total_per_density_rmout[,i] <- scale(total_per_density_rmout[,i])
}

install.packages("broom", dep=T)
library(broom)
library(MASS)
tidy(mod2)
glance(mod2)

qqnorm(total_per_density_rmout$cctv)
qqline(total_per_density_rmout$cctv)


qqnorm(total_per_density$cctv)


mod1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=total_per_density_rmout[,-c(1:2)])
summary(mod1)     
mod2 <- step(mod1, direction = "both")
summary(mod2)

mod1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=total_per_density[,-c(1:2)])
summary(mod1)     
mod2 <- step(mod1, direction = "both")
summary(mod2)

standard1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=standard[,-c(1:2)])
summary(standard1)     
standard2 <- step(standard1, direction = "both")
summary(standard2)

original1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=original[,-c(1:2)])
summary(original1)     
original2 <- step(original1, direction = "both")
summary(original2)

tab_model(original2, standard2)



cat(stargazer(original2, standard2, type = 'text', title = '회귀분석 비교 결과'), sep="\n")


if (!require(stargazer)) {
  install.packages('stargazer')
  library(stargazer)
}
install.packages("sjPlot")
library(sjPlot)
library(moonBook)
setwd("c:/Users/may/Desktop/data")

par(mfrow = c(2,2))
qqnorm(seoul$violence, main = "normal")
qqline(seoul$violence)
qqnorm(sqrt(seoul$violence), main = "sqrt")
qqline(sqrt(seoul$violence))
qqnorm(scale(seoul$violence), main = "scale")
qqline(scale(seoul$violence))
qqnorm(log(seoul$violence), main = "log")
qqline(log(seoul$violence))

hist(seoul$violence)
hist(sqrt(seoul$violence))
hist(scale(seoul$violence))
hist(log(seoul$violence))

typeof(seoul$lights)
typeof(as.vector(seoul[,3]))
class(seoul$lights)
class(seoul[,3])

qq <- function (data,index){
  par(mfrow = c(2,2))
  qqnorm(unlist(data[,index]), main = "normal")
  qqline(unlist(data[,index]))
  qqnorm(sqrt(unlist(data[,index])), main = "sqrt")
  qqline(sqrt(unlist(data[,index])))
  qqnorm(scale(unlist(data[,index])), main = "scale")
  qqline(scale(unlist(data[,index])))
  qqnorm(log(unlist(data[,index])), main = "log")
  qqline(log(unlist(data[,index])))
}


hi <- function (data,index){
  hist(unlist(data[,index]), main = "normal")
  hist(sqrt(unlist(data[,index])), main = "sqrt")
  hist(scale(unlist(data[,index])), main = "scale")
  hist(log(unlist(data[,index])), main = "log")
}

qq(standard_vr[,-c(1:2)],8)
hi(standard_vr[,-c(1:2)],8)
log(standard_vr$policestation)
#
#sqrt : pop_density, single_rate, 
#log : lights(중구 삭제 고려), pub, cctv, policestation, policeman, homi.ten, robber.ten, sexual.ten, theft.ten,grdp
is.na(standard_vr$homi.ten)


standard_vr2 <- standard_vr[,-4]
standard_vr2$pop_density <- sqrt(standard_vr$pop_density)
standard_vr2$single_rate <- sqrt(standard_vr$single_rate)
standard_vr2$lights <- log(standard_vr$lights)
standard_vr2$pub <- log(standard_vr$pub)
standard_vr2$cctv <- log(standard_vr$cctv)
standard_vr2$policestation <- log(standard_vr$policestation)
standard_vr2$policeman <- log(standard_vr$policeman)
standard_vr2$grdp <- log(standard_vr$grdp)
standard_vr2$homi.ten <- log(standard_vr$homi.ten)
standard_vr2$robber.ten <- log(standard_vr$robber.ten)
standard_vr2$sexual.ten <- log(standard_vr$sexual.ten)
standard_vr2$theft.ten <- log(standard_vr$theft.ten)
standard_vr2$violence.ten <- log(standard_vr$violence.ten)

standard_vr2 <- standard_vr2[-c(77,114,188,190,457,434:452,399),]
standard_vr2 <- standard_vr2[-c(398,429:432),]



ggpairs(standard_vr2[-c(433:452),-c(1:2)])
cor(standard_vr2[,-c(1:2)])

which(standard_vr2$pub < -1)

standard_vr2[-c(433:451),-c(1:2)]

standard1 <- lm(homi.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr2[,-c(1:2)])
summary(standard1)  
standard2 <- step(standard1, direction = "both")
summary(standard2)

standard11 <- lm(homi.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman , data=standard_vr22[,-c(1:2)])
summary(standard11)  
standard22 <- step(standard11, direction = "both")
summary(standard22)

tab_model(standard2, standard22, show.p = TRUE, 
          dv.labels = c("2004-2022 homicide", "2010-2022 homicide"))

predict(standard22, standard_vr221[13,])
for(i in 1:7){
predicted_vr22[(5*i-4):(5*i),11] <- predict(standard22, predicted_vr22[(5*i-4):(5*i),])
}

standard1 <- lm(robber.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr2[,-c(1:2)])
summary(standard1)  
standard2 <- step(standard1, direction = "both")
summary(standard2)

standard11 <- lm(robber.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr22[,-c(1:2)])
summary(standard11)  
standard22 <- step(standard11, direction = "both")
summary(standard22)

for(i in 1:7){
  predicted_vr22[(5*i-4):(5*i),12] <- predict(standard22, predicted_vr22[(5*i-4):(5*i),])
}

tab_model(standard2, standard22, show.p = TRUE, 
          dv.labels = c("2004-2022 robber", "2010-2022 robber"))

standard11 <- lm(sexual.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr22[,-c(1:2)])
summary(standard11)  
standard22 <- step(standard11, direction = "both")
summary(standard22)

for(i in 1:7){
  predicted_vr22[(5*i-4):(5*i),13] <- predict(standard22, predicted_vr22[(5*i-4):(5*i),])
}

standard1 <- lm(sexual.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr2[,-c(1:2)])
summary(standard1)  
standard2 <- step(standard1, direction = "both")
summary(standard2)

tab_model(standard2, standard22, show.p = TRUE, 
          dv.labels = c("2004-2022 sexual", "2010-2022 sexual"))

standard1 <- lm(theft.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr2[,-c(1:2)])
summary(standard1)  
standard2 <- step(standard1, direction = "both")
summary(standard2)

standard11 <- lm(theft.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr22[,-c(1:2)])
summary(standard11)  
standard22 <- step(standard11, direction = "both")
summary(standard22)

for(i in 1:7){
  predicted_vr22[(5*i-4):(5*i),14] <- predict(standard22, predicted_vr22[(5*i-4):(5*i),])
}

tab_model(standard2, standard22, show.p = TRUE, 
          dv.labels = c("2004-2022 theft", "2010-2022 theft"))

standard1 <- lm(violence.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr2[,-c(1:2)])
summary(standard1)  
standard2 <- step(standard1, direction = "both")
summary(standard2)

standard11 <- lm(violence.ten~lights+pub+pop_density+grdp+policestation+cctv+single_rate+policeman, data=standard_vr22[,-c(1:2)])
summary(standard11)  
standard22 <- step(standard11, direction = "both")
summary(standard22)

for(i in 1:7){
  predicted_vr22[(5*i-4):(5*i),15] <- predict(standard22, predicted_vr22[(5*i-4):(5*i),])
}


tab_model(standard2, standard22, show.p = TRUE, 
          dv.labels = c("2004-2022 violence", "2010-2022 violence"))


write_xlsx(predicted_vr22,path="c:/Users/may/Desktop/data/predicted_vr22.xlsx")
write_xlsx(standard_vr22,path="c:/Users/may/Desktop/data/standard_vr22.xlsx")
write_xlsx(standard_vr2,path="c:/Users/may/Desktop/data/standard_vr2.xlsx")



library(prophet)
prophet_model <- prophet(standard_vr2$pop_density)
future <- make_future_dataframe(prophet_model, periods = n)  # n은 예측할 기간
forecast <- predict(prophet_model, future)


predict(standard22, predicted_vr22[1:5],)



library(forecast)

# ARIMA 모델 자동 적합 예제
ts_data <- ts(standard_vr2$pop_density, frequency = 1)

# ARIMA 모델 자동 적합
arima_model <- auto.arima(ts_data)

# 예측 수행
forecast_result <- forecast(arima_model, h = 5)

summary(forecast_result)
plot(forecast_result)





vif(standard2)

standard_vr22 <- subset(standard_vr2, year > 2009)

predict(standard2,standard_vr2[14,-c(1:2)])
exp(6.616094)

qq(original,15)
hi(original,15)
par(mfrow=c(1,1))
plot(standard_vr2$pub,standard_vr2$cctv)
standard_vr2 <- standard_vr2[-399,]


shapiro.test(original$violence)
shapiro.test(sqrt(original$violence))
shapiro.test(scale(original$violence))
shapiro.test(log(original$violence))
#origin normalization
#normal : population,policestation
#sqrt : homicide
#scale : 
#log : lights, pub, grdp, cctv, single,policeman,robber,sexual, theft, violence
#제외 :

standard <- original
standard$homicide <- sqrt(original$homicide)
standard$lights <- log(original$lights)
standard$pub  <- log(original$pub)
standard$grdp <- log(original$grdp)
standard$cctv <- log(original$cctv)
standard$single <- log(original$single)
standard$policeman <- log(original$policeman)
standard$robber <- log(original$robber)
standard$sexual <- log(original$sexual)
standard$theft <- log(original$theft)
standard$violence <- log(original$violence)


ho <- function(data,index){
  print(shapiro.test(unlist(data[,index])))
  print(shapiro.test(sqrt(unlist(data[,index]))))
  print(shapiro.test(scale(unlist(data[,index]))))
  print(shapiro.test(log(unlist(data[,index]))))
}

qq(standard_v3,11)
hi(standard_v3,11)
ho(standard_v3,15)
#normal : 
#log : lights, pub, grdp, policestation, cctv, single,policeman, robber, sexual, theft,violence,total
#sqrt : homicide
#scale :






standard_v3$homicide <- sqrt(standard_v3$homicide)
standard_v3$lights <- log(standard_v3$lights)
standard_v3$pub  <- log(standard_v3$pub)
standard_v3$grdp <- log(standard_v3$grdp)
standard_v3$policestation <- log(standard_v3$policestation)
standard_v3$cctv <- log(standard_v3$cctv)
standard_v3$single <- log(standard_v3$single)
standard_v3$policeman <- log(standard_v3$policeman)
standard_v3$robber <- log(standard_v3$robber)
standard_v3$sexual <- log(standard_v3$sexual)
standard_v3$theft <- log(standard_v3$theft)
standard_v3$violence <- log(standard_v3$violence)
standard_v3$total_crime <- log(standard_v3$total_crime)

library(GGally)
ggpairs(original_base[c(7:19),c(3:18)])
ggpairs(standard_v32[c(7:19),c(3:15)])
cor(original_base[c(7:19),c(3:18)])
cor(standard_v32[c(7:19),c(3:15)])
ggpairs(standard_vr[,-c(1,2)])


standard_vr <- standard_vr[,-4]




#seoul nomailization
#normal : policestation, single, policeman, robber, theft
#sqrt : pub
#scale : sexual
#log : amount.pop, lights, cctv, homicide, violence
#제외권장 : grdp

seoul.stdd <- seoul
seoul.stdd$amount.pop <- log(seoul$amount.pop)
seoul.stdd$lights <- log(seoul$lights)
seoul.stdd$pub <- sqrt(seoul$pub)
seoul.stdd$cctv <- log(seoul$cctv)
seoul.stdd$homicide <- log(seoul$homicide)
seoul.stdd$population <- log(seoul$violence)
seoul.stdd$policestation <- seoul$policestation
seoul.stdd$single <- seoul$single
seoul.stdd$policeman <- seoul$policeman
seoul.stdd$robber <- seoul$robber
seoul.stdd$theft <- seoul$theft


hist()hist(original$population)
hist(sqrt(original$population))
hist(scale(original$population))
hist(log(original$population))

mod1 <- lm(total_crime~lights+pub+grdp+policestation+cctv+single+policeman, data=강남구[,-c(1:2)])
summary(mod1)     
mod2 <- step(mod1, direction = "both")
summary(mod2)


model_noInter <- lm(total_crime~lights+pub+grdp+policestation+cctv+single+policeman -1 , data=강남구[,-c(1:2)])
summary(model_noInter)     
model_noInter_step <- step(model_noInter, direction = "both")
summary(model_noInter_step)

ggpairs(강남구[,-c(1:2)])
qqPlot(강남구[,-c(1:2)])



model <- lm(total_crime~lights+pub+grdp+policestation+cctv+single+policeman , data=standard_v32[,-c(1:2)])
summary(model)     
model_step <- step(model, direction = "both")
summary(model_step)


tab_model(model_step, model_noInter_step, dv.labels =c('stepwise','stepwise & noIntercept'),p.style = "star")


predict(model_step, standard_v32[20:38,])
as.list(standard_v32[20:38,15]-predict(model_step, standard_v32[20:38,]))
sum(abs(standard_v32[20:38,15]-predict(model_step, standard_v32[20:38,])))

predict(model_noInter_step, standard_v32[20:38,])
as.list(standard_v32[20:38,15]-predict(model_noInter_step, standard_v32[20:38,]))
sum(abs(standard_v32[20:38,15]-predict(model_noInter_step, standard_v32[20:38,])))


for(i in 1:25){
  temp2<-levels(as.factor(standard_v32$local))[i]
  assign(temp2,standard_v32[c(which(standard_v32$local == levels(as.factor(standard_v32$local))[i])),])}


model_gu_noInter <- lm(robber~lights+pub+grdp+policestation+cctv+single+policeman -1 , data=강남구[,-c(1:2)])
summary(model_gu_noInter)     
model_gu_noInter_step <- step(model_gu_noInter, direction = "both")
summary(model_gu_noInter_step)


model_gu_noInter <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman , data=standard_v32[275:285,-c(1:2)])
summary(model_gu_noInter)     
model_gu_noInter_step <- step(model_gu_noInter)
summary(model_gu_noInter_step)


model_gu <- lm(total_crime~lights+pub+grdp+policestation+cctv+single+policeman , data=서초구[,-c(1:2)])
summary(model_gu)     
model_gu_step <- step(model_gu, direction = "both")
summary(model_gu_step)

tab_model(model_gu_step, model_gu_noInter_step, dv.labels = c('model_step','model_noInter_step'), string.p = 'P-value')

install.packages("sjPlot")
library(sjPlot)

anova(model_gu_step)


predict(mod2, pred_data[1,])



gupred_homi <- function (guname){

model_gu <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman , data=guname[,-c(1:2)])
model_gu_step <- step(model_gu, direction = "both")

model_gu_noInter <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman -1, data=guname[,-c(1:2)])
model_gu_noInter_step <- step(model_gu_noInter, direction = "both")

title <- guname[1,2]

tab_model(model_gu_step, model_gu_noInter_step, dv.labels = c(paste(title, paste('homicide','model_step')),paste(title, paste('homicide','model_noInter_step'))), string.p = 'P-value')

return(model_gu_step)

}

gupred_robber <- function (guname){
  
  model_gu <- lm(robber~lights+pub+grdp+policestation+cctv+single+policeman , data=guname[,-c(1:2)])
  model_gu_step <- step(model_gu, direction = "both")
  
  model_gu_noInter <- lm(robber~lights+pub+grdp+policestation+cctv+single+policeman -1, data=guname[,-c(1:2)])
  model_gu_noInter_step <- step(model_gu_noInter, direction = "both")
  
  title <- guname[1,2]
  
  tab_model(model_gu_step, model_gu_noInter_step, dv.labels = c(paste(title, paste('robber','model_step')),paste(title, paste('robber','model_noInter_step'))), string.p = 'P-value')
  return(model_gu_step)
}

gupred_sexual <- function (guname){
  
  model_gu <- lm(sexual~lights+pub+grdp+policestation+cctv+single+policeman , data=guname[,-c(1:2)])
  model_gu_step <- step(model_gu, direction = "both")
  
  model_gu_noInter <- lm(sexual~lights+pub+grdp+policestation+cctv+single+policeman -1, data=guname[,-c(1:2)])
  model_gu_noInter_step <- step(model_gu_noInter, direction = "both")
  
  title <- guname[1,2]
  
  tab_model(model_gu_step, model_gu_noInter_step, dv.labels = c(paste(title, paste('sexual','model_step')),paste(title, paste('sexual','model_noInter_step'))), string.p = 'P-value')
  return(model_gu_step)
}

gupred_theft <- function (guname){
  
  model_gu <- lm(theft~lights+pub+grdp+policestation+cctv+single+policeman , data=guname[,-c(1:2)])
  model_gu_step <- step(model_gu, direction = "both")
  
  model_gu_noInter <- lm(theft~lights+pub+grdp+policestation+cctv+single+policeman -1, data=guname[,-c(1:2)])
  model_gu_noInter_step <- step(model_gu_noInter, direction = "both")
  
  title <- guname[1,2]
  
  tab_model(model_gu_step, model_gu_noInter_step, dv.labels = c(paste(title, paste('theft','model_step')),paste(title, paste('theft','model_noInter_step'))), string.p = 'P-value')
  return(model_gu_step)
}

gupred_violence <- function (guname){
  
  model_gu <- lm(violence~lights+pub+grdp+policestation+cctv+single+policeman , data=guname[,-c(1:2)])
  model_gu_step <- step(model_gu, direction = "both")
  
  model_gu_noInter <- lm(violence~lights+pub+grdp+policestation+cctv+single+policeman -1, data=guname[,-c(1:2)])
  model_gu_noInter_step <- step(model_gu_noInter, direction = "both")
  
  title <- guname[1,2]
  
  tab_model(model_gu_step, model_gu_noInter_step, dv.labels = c(paste(title, paste('violence','model_step')),paste(title, paste('violence','model_noInter_step'))), string.p = 'P-value')
  return(model_gu_step)
}


gupred2 <- function (guname){
model_gu <- lm(total_crime~lights+pub+grdp+policestation+cctv+single+policeman , data=guname[,-c(1:2)])
model_gu_step <- step(model_gu, direction = "both")
title <- guname[1,2]
tab_model(model_gu_step, model_gu_noInter_step, dv.labels = c(paste(title, paste('total crime','model_step')),paste(title, paste('total crime','model_noInter_step'))), string.p = 'P-value')
return(model_gu_step)
}

rm(predicted_data)

year <- c(2023:2034)
local <- rep('강남구',12)
predicted_data <- data.frame(year,local)

model_gu_step <- gupred_homi(강남구)
pred_homicide <- predict(model_gu_step,pred_data[c(which(pred_data$local=="강남구")),])
predicted_data <- cbind(predicted_data,pred_homicide)
model_gu_step <- gupred_robber(강남구)
pred_robber <- predict(model_gu_step,pred_data[c(which(pred_data$local=="강남구")),])
predicted_data <- cbind(predicted_data,pred_robber)
model_gu_step <- gupred_sexual(강남구)
pred_sexual <- predict(model_gu_step,pred_data[c(which(pred_data$local=="강남구")),])
predicted_data <- cbind(predicted_data,pred_sexual)
model_gu_step <- gupred_theft(강남구)
pred_theft <- predict(model_gu_step,pred_data[c(which(pred_data$local=="강남구")),])
predicted_data <- cbind(predicted_data,pred_theft)
model_gu_step <- gupred_violence(강남구)
pred_violence <- predict(model_gu_step,pred_data[c(which(pred_data$local=="강남구")),])
predicted_data <- cbind(predicted_data,pred_violence)
model_gu_step <- gupred2(강남구)
pred_total_crime <- predict(model_gu_step,pred_data[c(which(pred_data$local=="강남구")),])
predicted_data <- cbind(predicted_data,pred_total_crime)



model_gu <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman , data=standard_v32[275:285,-c(1:2)])
model_gu_step <- step(model_gu, direction = "both")

model_gu_noInter <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman -1, data=standard_v32[275:285,-c(1:2)])
model_gu_noInter_step <- step(model_gu_noInter, direction = "both")

title <- 서초구[1,2]

tab_model(model_gu_step, model_gu_noInter_step, dv.labels = c(paste('서초구', paste('homicide','model_step')),paste('서초구', paste('homicide','model_noInter_step'))), string.p = 'P-value')


gupred_robber(서초구)
gupred_sexual(서초구)
gupred_theft(서초구)
gupred_violence(서초구)
gupred2(서초구)

gupred_homi(송파구)
gupred_robber(송파구)
gupred_sexual(송파구)
gupred_theft(송파구)
gupred_violence(송파구)
gupred2(송파구)

gupred_homi(영등포구)
gupred_robber(영등포구)
gupred_sexual(영등포구)
gupred_theft(영등포구)
gupred_violence(영등포구)
gupred2(영등포구)


gupred_homi(성동구)
gupred_robber(성동구)
gupred_sexual(성동구)
gupred_theft(성동구)
gupred_violence(성동구)
gupred2(성동구)


gupred_homi(노원구)
gupred_robber(노원구)
gupred_sexual(노원구)
gupred_theft(노원구)
gupred_violence(노원구)
gupred2(노원구)

gupred_homi(강북구)
gupred_robber(강북구)
gupred_sexual(강북구)
gupred_theft(강북구)
gupred_violence(강북구)
gupred2(강북구)




ggpairs(seoul[,-1])
seoul.stdd$grdp <- seoul$grdp


mod1 <- lm(robber~lights+lights+pub+grdp+policestation+cctv+single+policeman, data=seoul.stdd[,-c(1)])
summary(mod1)     
mod2 <- step(mod1, direction = "both")
summary(mod2)

tab_model(mod2, p.style = "star")


test_data <- original[c(1:19),-2]
test_data$pub <- sqrt(test_data$pub)
test_data$cctv <- log(test_data$cctv)
test_data$homicide <- log(test_data$homicide)

tab_model(mod2, p.style = "star")










(predict(mod2,standard_v32[43,]))*345754/100000

coef(mod2)



ggpairs(seoul.stdd[,-1])

shapiro.test(seoul$amount.pop)
shapiro.test(seoul.stdd$amount.pop)
shapiro.test(seoul$lights)
shapiro.test(seoul.stdd$lights)
shapiro.test(seoul$pub)
shapiro.test(seoul.stdd$pub)
shapiro.test(seoul$grdp)
shapiro.test(seoul.stdd$grdp)
shapiro.test(seoul$policestation)
shapiro.test(seoul.stdd$policestation)
shapiro.test(seoul$cctv)
shapiro.test(seoul.stdd$cctv)
shapiro.test(seoul$single)
shapiro.test(seoul.stdd$single)
shapiro.test(seoul$policeman)
shapiro.test(seoul.stdd$policeman)
shapiro.test(seoul$homicide)
shapiro.test(seoul.stdd$homicide)
shapiro.test(seoul$robber)
shapiro.test(seoul.stdd$robber)
shapiro.test(seoul$sexual)
shapiro.test(seoul.stdd$sexual)
shapiro.test(seoul$theft)
shapiro.test(seoul.stdd$theft)
shapiro.test(seoul$violence)
shapiro.test(seoul.stdd$violence)

for(i in 11:15){
standard[,i] <- sqrt(original[,i])
}

for(i in 3:10){
  standard[,i] <- log(original[,i])
}

standard$policestation <- scale(original$policestation)
standard$population  <- scale(original$population)



#seoul 정규화

seoul.stdd <- seoul
colnames(seoul.stdd[,2]) <- "population"



for(i in 10:14){
  seoul.stdd[,i] <- sqrt(seoul[,i])
}

for(i in 2:9){
  seoul.stdd[,i] <- log(seoul[,i])
}

seoul.stdd$policestation <- scale(seoul$policestation)
seoul.stdd$population  <- scale(seoul$lights)




total_per_density_std <- total_per_density

for(i in 10:14){
  total_per_density_std[,i] <- sqrt(total_per_density[,i])
}

for(i in 3:9){
  total_per_density_std[,i] <- log(total_per_density[,i])
}

total_per_density_std$policestation <- scale(total_per_density$policestation)


shapiro.test(standard.v1$population)
wilcox.test(standard.v1$population)

qqnorm(standard.v1$population)
qqline(standard.v1$population)

shapiro.test(seoul$lights)
wilcox.test(seoul$lights)

qqnorm(seoul$lights)
qqline(seoul$lights)

shapiro.test(seoul.stdd$lights)
wilcox.test(seoul.stdd$lights)

qqnorm(seoul.stdd$lights)
qqline(seoul.stdd$lights)

par(mfrow = c(1,1))

library(GGally)

ggpairs(seoul.stdd[,-2], upper = "blank")

shapiro.test(standard.v1$population)
wilcox.test(standard.v1$population)



par(mfrow = c(2,2))

qqnorm(seoul$lights, main = "normal")
qqline(seoul$lights)
hist(seoul$lights)

qqnorm(sqrt(seoul$lights), main = "sqrt")
qqline(sqrt(seoul$lights))
hist(sqrt(seoul$lights))

qqnorm(scale(seoul$lights), main = "scale")
qqline(scale(seoul$lights))
hist(scale(seoul$lights))

qqnorm(log(seoul$lights), main = "log")
qqline(log(seoul$lights))
hist(log(seoul$lights))

library(MASS)
library(car)
library(stats)
library(ggplot2)

seoul %>% ggplot(aes(sqrt(lights)))+geom_density(col="red", fill="red", alpha=0.05)+theme_classic()

qqPlot(log(seoul$lights), col.lines = "red")

tab_model(mod2)

tpds1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=total_per_density_std[,-c(1:2)])
summary(tpds1)
tpds2 <- step(tpds1, direction = "both")
summary(tpds2)

original1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=original[c(1:19),-c(1:2)])
summary(original1)     
original2 <- step(original1, direction = "both")
summary(original2)


standard1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=standard[c(1:19),-c(1:2)])
summary(standard1)     
standard2 <- step(standard1, direction = "both")
summary(standard2)

tpdsr1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=tpdsr[c(1:19),-c(1:2)])
summary(tpdsr1)     
tpdsr2 <- step(tpdsr1, direction = "both")
summary(tpdsr2)

tab_model(original2, standard2, tpds2, tpdsr2)

install.packages("GGally")
library(GGally)

colnames(standard)[3] <- "population"

typeof(standard$population)
standard$policestation<- as.numeric(standard$policestation)
ggpairs(standard[,-c(1:2)])
ggpairs(original[,-c(1:2)])
cor(tpdsr[,-c(1:2)])

pairs((tpdsr[,-c(1:2)]))
plot(tpdsr[,-c(1:2)])



#회귀분석결과 표로 나타내기

library(sjPlot)
library(sjmisc)
library(sjlabelled)

tab_model(stdd2,p.style = "stars")






install.packages("webshot")
library(webshot)
webshot::install_phantomjs()
library(htmltools)
webshot("http://localhost:29878/session/file1e404a496d38.html","compare_homicide.png")



install.packages("lm.beta")
library(lm.beta)

lm.beta(standard2)


par(mfrow = c(1,1))

qqplot(강남구[,-c(1:2)])
pairs(강남구[,-c(1:2)], main="multi plots")

par(mfrow = c(1, 2))
plot(tpdsr2, which = c(4, 6))

cor(x=강남구[,3:9], y=강남구[,3:9], method = "spearman")



pairs(강남구[,-(1:2)], panel = panel.smooth)


cor(강남구[,-c(1:2)])

stdd1 <- lm(robber~lights+pub+cctv+single, data=standard_v32[,-c(1:2)])
summary(stdd1)     
vif(stdd1)
stdd2 <- step(stdd1)
summary(stdd2)


stdd1 <- lm(homicide~pub+policestation+policeman, data=강남구[,-c(1:2)])
summary(stdd1)     
vif(stdd1)
stdd2 <- step(stdd1)
summary(stdd2)
vif(stdd2)



homicide~lights+pub+grdp+policestation+cctv+single+policeman

stdd1 <- lm(total_crime~lights+pub+grdp+policestation+policeman , data=강북구[,-c(1:2)])
summary(stdd1)
vif(stdd1)
stdd1 <- step(stdd1, direction="both")
summary(stdd1)
vif(stdd1)
tab_model(stdd1, string.p = 'P-value')

predict(stdd1, pred_data[25:36,-c(1:2)])


predicted_data[73:84,8] <- predict(stdd1, pred_data[25:36,-c(1:2)])

predicted_data[73:84,1] <- c(2023:2034)
predicted_data[73:84,2] <- "강북구"

predicted_data[73:84,4] <- 0

predicted_data[1:3,]

library(ggplot2)


predicted_data$year <- as.factor(predicted_data$year)
ggplot(data = gu_predict_data[1:24,],aes(year, homicide, group=1, size=1))+geom_line()


ggplot(data = final[145:168,], aes(x = year)) +
  geom_line(aes(y = homi.ten, color = "homicide"), size = 1, linetype = "solid") +
  geom_line(aes(y = robber.ten, color = "robber"), size = 1, linetype = "solid") +
  geom_line(aes(y = sexual.ten, color = "sexual"), size = 1, linetype = "solid") +
  geom_line(aes(y = theft.ten, color = "theft"), size = 1, linetype = "solid") +
  geom_line(aes(y = violence.ten, color = "violence"), size = 1, linetype = "solid") +
  
  labs(title = "Crime Prediction Over Years in 송파구",
       x = "Year",
       y = "Crime Values",
       color = "Crime Type") +
  theme_minimal() +
  scale_x_continuous(breaks = seq(min(gu_predict_data$year), max(gu_predict_data$year), by = 1))



강남구예측 <- 강남구[,c(1,10:15)]
강남구예측[20:31,2:7] <- NA
강남구예측 <- rbind(강남구예측,predicted_data[1:12,c(1,3:8)])

library(writexl)
write_xlsx(predicted_data, "c:/Users/may/Desktop/data/predicted_data.xlsx")
write_xlsx(standard_v32, "c:/Users/may/Desktop/data/standard32.xlsx")



library(sjPlot)

library(Car)

head(predicted_data)

plot(강남구[,-c(1:2)])

ggpairs(standard[,-c(1:2)])
ggpairs(original[,-c(1:2)])

#standard pub 이상치 발견 -> 403행 "은평구 2007" -> 삭제

standard.v1 <- standard[-403,]
ggpairs(standard.v1[,-c(1:2)])
plot(standard.v1[,-c(1:2)])
cor(standard.v1[,-c(1:2)])

stdd1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=standard.v1[c(1:19),-c(1:2)])
summary(stdd1)
vif(stdd1)
stdd2 <- step(stdd1, direction = "both")
summary(stdd2)

stdd1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=standard.v1[c(20:40),-c(1:2)])
summary(stdd1)     
stdd2 <- step(stdd1, direction = "both")
summary(stdd2)


stdd1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=seoul.stdd[,-1])
summary(stdd1)     
stdd2 <- step(stdd1, direction = "both")
summary(stdd2)





library(caret)
install.packages("forecast")
library(forecast)
fit <- auto.arima(standard_v32[c(1:19),3])
summary(fit)
forecast_result <- forecast(fit, h=1)

arima(standard_v32[c(1:19),3])

# 모델이 학습된 시계열 데이터
train_data <- standard_v32[c(1:19), 3]

# ARIMA 모델 학습
arima_model <- arima(train_data)

# 향후 10 시점에 대한 예측
forecast_result <- predict(arima_model, n.ahead = 1)

# 예측값 출력
forecast_values <- forecast_result$pred
print(forecast_values)




library(forecast)
install.packages("vars")
library(vars)
install.packages("prophet")
library(prophet)


data <- standard_v32[c(1:19),]

# 시계열 객체로 변환
ts_data <- ts(data$lights, frequency = 1, start = 2004)

# ARIMA 모델 피팅
arima_model <- auto.arima(ts_data)

# 다음 연도의 예측
forecast_result <- forecast(arima_model, h = 12)  # 예측 기간 설정 (예: 12개월)

summary(forecast_result)

# 예측 결과 시각화
plot(forecast_result, main = 'ARIMA Forecast for lights Installation')

temp2 <- data.frame(matrix(NA, nrow = 300, ncol = 11))
colnames(temp2) <- paste0("Column", 1:11)

temp2$Column1 <- rep(2023:2027)
predicted_vr22 <- temp2[1:35,1:10]
colnames(predicted_vr22) <- c("year","local","pop_density","lights","pub","cctv","grdp","policestation","policeman","single_rate")

for(i in 1:8){
data <- standard_vr2[39:57,]
temp2[31:35,2] <- standard_vr2[39,2]
ts_data <- ts(data[,(i+2)], frequency = 1, start = 2004)
arima_model <- auto.arima(ts_data)
forecast_result <- forecast(arima_model, h = 5)
temp2[31:35,(i+2)] <- forecast_result$mean
}

data <- standard_vr2[1:19,]
temp2[1:19,2] <- standard_vr22[1,2]
ts_data2 <- ts(data[,3], frequency = 1, start = 2004)
arima_model2 <- auto.arima(ts_data2)
forecast_result2 <- forecast(arima_model2, h = 13)
temp2[1:13,3] <- forecast_result2$mean




temp <- data.frame(matrix(NA, nrow = 300, ncol = 10))
colnames(temp) <- paste0("Column", 1:10)
  
  for(i in 1:25){
    for(j in 3:9){
data <- standard_v32[(19*(i-1)+1):(19*i),]
temp[((12*(i-1)+1):(12*i)),2]  <- standard_v32[19*(i-1)+1,2]

# 시계열 객체로 변환
ts_data <- ts(data[,j], frequency = 1, start = 2004)

# ARIMA 모델 피팅
arima_model <- auto.arima(ts_data)

# 다음 연도의 예측
forecast_result <- forecast(arima_model, h = 12)  # 예측 기간 설정 (예: 12개월)



temp[((12*(i-1)+1):(12*i)),j] <-  forecast_result$mean
  }}



temp[,1] <- rep(2023:2034)

pred_data <- temp

colnames(pred_data) <- c('year','local','lights','pub','grdp','policestation','cctv','single','policeman')

# 교차 검증 설정
control <- trainControl(method = "cv", number = 10)  # 10-fold 교차 검증

# 모델 학습 및 검증
model <- train(lights ~ ., data = seoul.stdd[,-1], method = "lm", trControl = control)

model <- train(homicide ~ lights+pub+grdp+policestation+cctv+single+policeman, 
               data = na.omit(seoul.stdd[,-1]),
               method = "lm", 
               trControl = control,
               na.action = na.pass)



# 결과 확인standard# 결과 확인
print(model)















#다중공선성검사
#다중공선성 검사 방법:
#Variance Inflation Factor (VIF):
  
#VIF는 각 독립 변수의 분산이 다른 독립 변수들에 의해 얼마나 증폭되는지를 나타내는 지표입니다.
#VIF 값이 크다면 다중공선성의 증거로 간주될 수 있습니다. 일반적으로 VIF 값이 10보다 크면 다중공선성의 문제가 있을 가능성이 높습니다.
install.packages("car")
library(car)
vif_values <- vif(stdd2)


#잔차값 검사
residuals <- residuals(stdd2)
qqnorm(residuals)
qqline(residuals)

plot(fitted(stdd2), residuals, 
     xlab = "Fitted values", 
     ylab = "Residuals", 
     main = "Residuals vs Fitted values")

acf(residuals)
hist(residuals)

lights <- c(8.790117,8.808519,8.807173,9.095939,9.164506)
policeman <-c(6.781058,6.804615,6.850126,6.846943,6.844815)
homicide <- c(3.000000,3.316625,3.316625,2.828427,3.162278)
test_data <- data.frame(lights,policeman,homicide)

predictions <- predict(stdd2, newdata = test_data[1,])
error <- test_data$homicide - predictions
error

# RMSE 계산
rmse <- sqrt(mean(error^2))
print(rmse)




seoul.stdd$population <- as.numeric(seoul.stdd$population)
ggpairs(seoul.stdd)
seoul.stdd$policestation <- as.numeric(seoul.stdd$policestation)
cor(seoul.stdd)


#모델 테스트
set.seed(123)  # 재현성을 위한 랜덤 시드 설정
n <- nrow(seoul.stdd)
train_idx <- sample(1:n, 0.7 * n)  # 예: 70% 훈련 데이터
train_data <- data[train_idx, ]
test_data <- data[-train_idx, ]






original1 <- lm(homicide~lights+pub+grdp+policestation+cctv+single+policeman, data=original[c(1:19),-c(1:2)])
summary(original1)     
original2 <- step(original1, direction = "both")
summary(original2)


qqnorm(log(standard.v1$population))
qqline(log(standard.v1$population))

qqnorm(original$population)
qqline(original$population)


#이상치 탐지
# 1) 표준편차 이상치 탐지
# 1-1. policestation 이상치 탐지 및 행 제거
plot(seoul)
boxplot(stan[,15])
ggpairs(seoul)

mean_val <- mean(standard.v1$policeman)
sd_val <- sd(standard.v1$policeman)
threshold <- 2.5  # 예: 표준편차의 2배
outliers <- standard.v1$policeman < mean_val - threshold * sd_val |standard.v1$policeman > mean_val + threshold * sd_val

standard.v1[outliers,]

standard.v1 <- standard.v1[-c(outliers),]





z_scores <- (standard.v1$policestation - mean(standard.v1$policestation)) / sd(standard.v1$policestation)
filtered_standard.v1 <- standard.v1$policestation[abs(z_scores) < 3]

filtered_standard.v1


boxplot(standard.v1$policeman)
install.packages("ggplot2")
library(ggplot2)
ggplot(seoul)





model_gu_noInter <- lm(robber~lights+pub+grdp+policestation+cctv+single+policeman-1, data=강남구[,-c(1:2)])
summary(model_gu_noInter)     
model_gu_noInter_step <- step(model_gu_noInter, direction = "both")
summary(model_gu_noInter_step)

predict(model_gu_noInter_step,pred_data[1:12,])
